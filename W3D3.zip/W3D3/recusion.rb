require "byebug"

def range(s,e)
    return [s] if e <= s
    [s]+range(s+1,e)
end

def range_iter(s,e)
    arr = []
    (s..e).each do |ele|
        arr<<ele
    end
    arr
end

#p range_iter(1,5)

def exp_1(b, n)
    return 1 if n == 0
    b * exp_1(b, n-1)
end

# p exp_1(2, 3)

def exp_2(b, n)
    return 1 if n == 0
    return b if n == 1
    return b*b if n == 2
    return b*b*b if n == 3
    
    if n%2 == 0
        return exp_2(b, n/2)*b*b
    else
        return exp_2(b, (n-1)/2)*b*b*b
    end
end

# p exp_2(3,4) #=> 81
# p exp_2(2,5) #=> 32
# p exp_2(5,3) #=> 125
# p exp_2(6,4) #=>1296
class Array
    def deep_dup
        arr = []
        self.each do |ele|
            if ele.is_a?(Array)
                arr<<ele.deep_dup
            else
                arr += [ele]
            end
        end
        arr
    end
end

# p [1, [2], [3, [4]]].deep_dup
# robot_parts = [
#   ["nuts", "bolts", "washers"],
#   ["capacitors", "resistors", "inductors"]
# ]

# #robot_parts_copy = robot_parts.dup
# robot_parts_copy = robot_parts.deep_dup

# # shouldn't modify robot_parts
# robot_parts_copy[1] << "LEDs"
# # but it does
# p robot_parts[1] # => ["capacitors", "resistors", "inductors", "LEDs"]

def fib(n)
    return [0] if n == 0
    return [0,1] if n == 1
    last = fib(n-1)
    last<<last[-1] + last[-2]
end

#p fib(5)

def bsearch(array,target)
    return nil if array.length <= 1 && target != array[0]
    return array.length/2 if target == array[array.length/2]

    if target < array[array.length/2]
        bsearch(array[0...array.length/2], target)
    else
        res = bsearch(array[(array.length/2)..-1], target)
        return array.length/2 + res if res != nil
        return nil
    end
end

# p bsearch([1, 2, 3], 1) # => 0
# p bsearch([2, 3, 4, 5], 3) # => 1
# p bsearch([2, 4, 6, 8, 10], 6) # => 2
# p bsearch([1, 3, 4, 5, 9], 5) # => 3
# p bsearch([1, 2, 3, 4, 5, 6], 6) # => 5
# p bsearch([1, 2, 3, 4, 5, 6], 0) # => nil
# p bsearch([1, 2, 3, 4, 5, 7], 6) # => nil

def merge_sort(array)
    return array if array.length <= 1
    merge(merge_sort(array[0...array.length/2]), merge_sort(array[array.length/2..-1]))
end

def merge(array1, array2)
    merged = []

    # debugger
    while array1.length >= 1 && array2.length >= 1
        if array1[0] < array2[0]
            first1 = array1.shift
            merged << first1
        else
            first2 = array2.shift
            merged << first2
        end
    end

    if array1.empty? && !array2.empty?
        merged += array2
    elsif !array1.empty? && array2.empty?
        merged += array1
    end

    merged
end

def subsets(array)
    return [[]] if array.empty?
    subs = []
    prev_subs = subsets(array[0...-1])
    prev_subs.each do |sub|
        subs << (sub + [array[-1]])
    end
    prev_subs + subs
end

# p subsets([]) # => [[]]
# p subsets([1]) # => [[], [1]]
# p subsets([1, 2]) # => [[], [1], [2], [1, 2]]
# p subsets([1, 2, 3]) # => [[], [1], [2], [1, 2], [3], [1, 3], [2, 3], [1, 2, 3]]

def permutations(array)
    return [array] if array.length <= 1
    perms = []

    prev_perms = permutations(array[1..-1])
    prev_perms.each do |perm|
        (0..perm.length).each do |i|
            perms << perm[0...i] + [array[0]] + perm[i..-1]
        end
    end
    perms
end

# p permutations([1, 2, 3])

def greedy_make_change(num,coins=[25,10,5,1])
    coins.sort.reverse!
    return [num] if coins.include?(num)
    change = []
    (0...coins.length).each do |i|
        if num > coins[i]
            change<<coins[i]
            num -= coins[i]
            break
        end
    end
    change + greedy_make_change(num,coins)
end


p greedy_make_change(39,[30,7,2])